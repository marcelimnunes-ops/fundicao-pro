@echo off
setlocal enabledelayedexpansion
chcp 65001 > nul

set "BASE=%~dp0"

echo.
echo ╔════════════════════════════════════════════════════════════════╗
echo ║                                                                ║
echo ║        FUNDIÇÃO PRO - ORGANIZADOR FINAL DE ARQUIVOS           ║
echo ║                                                                ║
echo ╚════════════════════════════════════════════════════════════════╝
echo.

REM Criar pastas necessárias
echo Criando estrutura de pastas...
mkdir "%BASE%src\pages" 2>nul
mkdir "%BASE%src\components\ui" 2>nul
mkdir "%BASE%src\lib" 2>nul
mkdir "%BASE%src\hooks" 2>nul
mkdir "%BASE%src\styles" 2>nul
echo ✓ Pastas criadas
echo.

REM Mover PÁGINAS REACT (13 arquivos)
echo Movendo PAGINAS REACT...
move "%BASE%_app.tsx" "%BASE%src\pages\" /y >nul 2>&1
move "%BASE%login.tsx" "%BASE%src\pages\" /y >nul 2>&1
move "%BASE%index.tsx" "%BASE%src\pages\" /y >nul 2>&1
move "%BASE%apontamento.tsx" "%BASE%src\pages\" /y >nul 2>&1
move "%BASE%produtos.tsx" "%BASE%src\pages\" /y >nul 2>&1
move "%BASE%clientes.tsx" "%BASE%src\pages\" /y >nul 2>&1
move "%BASE%funcionarios.tsx" "%BASE%src\pages\" /y >nul 2>&1
move "%BASE%estoque.tsx" "%BASE%src\pages\" /y >nul 2>&1
move "%BASE%relatorios.tsx" "%BASE%src\pages\" /y >nul 2>&1
move "%BASE%gargalos.tsx" "%BASE%src\pages\" /y >nul 2>&1
move "%BASE%correlacoes.tsx" "%BASE%src\pages\" /y >nul 2>&1
move "%BASE%configuracoes.tsx" "%BASE%src\pages\" /y >nul 2>&1
move "%BASE%relatorios-avancados.tsx" "%BASE%src\pages\" /y >nul 2>&1
echo ✓ 13 paginas movidas
echo.

REM Mover COMPONENTES UI (9 arquivos)
echo Movendo COMPONENTES UI...
move "%BASE%Button.tsx" "%BASE%src\components\ui\" /y >nul 2>&1
move "%BASE%Card.tsx" "%BASE%src\components\ui\" /y >nul 2>&1
move "%BASE%Modal.tsx" "%BASE%src\components\ui\" /y >nul 2>&1
move "%BASE%Alert.tsx" "%BASE%src\components\ui\" /y >nul 2>&1
move "%BASE%FormInput.tsx" "%BASE%src\components\ui\" /y >nul 2>&1
move "%BASE%FormSelect.tsx" "%BASE%src\components\ui\" /y >nul 2>&1
move "%BASE%Table.tsx" "%BASE%src\components\ui\" /y >nul 2>&1
move "%BASE%Badge.tsx" "%BASE%src\components\ui\" /y >nul 2>&1
move "%BASE%Spinner.tsx" "%BASE%src\components\ui\" /y >nul 2>&1
echo ✓ 9 componentes movidos
echo.

REM Mover LAYOUT (1 arquivo)
echo Movendo LAYOUT...
move "%BASE%Layout.tsx" "%BASE%src\components\" /y >nul 2>&1
echo ✓ Layout movido
echo.

REM Mover LIB (3 arquivos)
echo Movendo LIB...
move "%BASE%supabase.ts" "%BASE%src\lib\" /y >nul 2>&1
move "%BASE%calculations.ts" "%BASE%src\lib\" /y >nul 2>&1
move "%BASE%types.ts" "%BASE%src\lib\" /y >nul 2>&1
echo ✓ 3 arquivos de lib movidos
echo.

REM Mover HOOKS (5 arquivos)
echo Movendo HOOKS...
move "%BASE%useProducao.ts" "%BASE%src\hooks\" /y >nul 2>&1
move "%BASE%useClientes.ts" "%BASE%src\hooks\" /y >nul 2>&1
move "%BASE%useEstoque.ts" "%BASE%src\hooks\" /y >nul 2>&1
move "%BASE%useForm.ts" "%BASE%src\hooks\" /y >nul 2>&1
move "%BASE%useDebounce.ts" "%BASE%src\hooks\" /y >nul 2>&1
echo ✓ 5 hooks movidos
echo.

REM Mover ESTILOS (1 arquivo)
echo Movendo ESTILOS...
move "%BASE%globals.css" "%BASE%src\styles\" /y >nul 2>&1
echo ✓ Estilos movidos
echo.

REM Mover CONFIGURAÇÕES (não move, só deixa na raiz)
echo ✓ Configuracoes ja estao na raiz
echo.

echo ╔════════════════════════════════════════════════════════════════╗
echo ║                                                                ║
echo ║              ✅ TUDO ORGANIZADO COM SUCESSO! ✅               ║
echo ║                                                                ║
echo ║  Total movido: 41 arquivos                                    ║
echo ║                                                                ║
echo ║  Proximos passos:                                             ║
echo ║  1. Abra GitHub Desktop                                       ║
echo ║  2. Faça Commit: "Add: Organizar estrutura do projeto"        ║
echo ║  3. Clique "Commit to main"                                   ║
echo ║  4. Clique "Push origin"                                      ║
echo ║  5. Vercel detecta automaticamente                            ║
echo ║  6. Deploy automático (3-5 minutos)                           ║
echo ║  7. Sistema ONLINE! 🚀                                        ║
echo ║                                                                ║
echo ╚════════════════════════════════════════════════════════════════╝
echo.
pause
